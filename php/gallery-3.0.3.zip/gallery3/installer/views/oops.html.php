<?php defined("SYSPATH") or die("No direct script access.") ?>
<h1> Oops! </h1>
<p>
  Something unexpected happened and we can't finish your install.
  We'll try to provide some details about the specific problem below.
</p>
<p class="error">
  <?php print $error ?>
</p>


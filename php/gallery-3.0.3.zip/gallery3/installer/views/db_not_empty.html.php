<?php defined("SYSPATH") or die("No direct script access.") ?>
<h1> Uh oh! </h1>
<p class="error">
  The database you provided already has Gallery 3 tables in it.
  Continuing with the install would overwrite your existing install.
  Please either use a different database,  delete the old tables,
  or choose a different table prefix.
</p>

import os
os.chdir(' /home/x/www/wjbzbmr/blog/category')
files= os.listdir('.')
for file in files:
        print file
        print file.decode('utf-8').encode('gbk')
        
        
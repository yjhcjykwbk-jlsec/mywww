#!/bin/sh
[ -z $1 ] && exit
user=$1
host="http://hi.baidu.com/"$user"/"

category_dir="blog/category/"
wget $host"/blog" -O "blog/index.html"
urllist=`cat blog/index.html |grep -o '<a href=[^>]*category[^"]*"' |grep -o  -E '"[^"]*"' |grep -o '[^"]*' `
for url in $urllist;do  
	file=`echo $url | grep -o '[^/]*$'`".html"
	echo $category_dir$file"<=""hi.baidu.com"$url 
	#[ -f $category_dir$file ] || 
	wget "hi.baidu.com"$url -O $category_dir$file 2>tmp; done
#
index_dir="blog/index/"
for i in `seq 19`;do 
	pagei=$index_dir$(($i-1))
	[ -f $pagei".html" ] || wget $host$pagei -O $pagei".html" 2>tmp || return
	urllist=`cat blog/index/$((i-1)).html |grep -o '<a href=[^>]*item[^"]*html"' |grep -o -E '"[^"]*"' |grep -o '[^"]*' `
	for url in $urllist;do
		file=`echo $url | grep -o '[^\/]*html'`
		echo $file 
		wget http://hi.baidu.com$url -O blog/item/$file
	done
	echo $urllist
done

#--index
#<a href="/%D6%D0%B9%FA%C4%D4%BD%EE/blog/item/3a680fa97b0b6c90cb130c9b.html" target="_blank">[Solution] NOI 2012</a>
#<a href="/%D6%D0%B9%FA%C4%D4%BD%EE/blog/category/%C0%ED%D0%D4%D3%E4%D4%C3"
#for file in `ls blog/index` `ls blog/category`;do
#	sed -i 's/<a href="http:\/\/hi.baidu.com\/%D6%D0%B9%FA%C4%D4%BD%EE\/*blog/<a href="\.\./g' blog/index/$file  ||
#	sed -i 's/<a href="http:\/\/hi.baidu.com\/%D6%D0%B9%FA%C4%D4%BD%EE\/*blog/<a href="\.\./g' blog/category/$file
##	sed -i 's/<a href="\/%D6%D0%B9%FA%C4%D4%BD%EE/<a href="\.\.\/\.\./g' blog/index/$file
#	sed -i 's/\/%D6%D0%B9%FA%C4%D4%BD%EE/\.\.\/\.\./g' blog/index/$file ||	sed -i 's/\/%D6%D0%B9%FA%C4%D4%BD%EE/\.\.\/\.\./g' blog/category/$file
#	echo "handled blog/index/$file"
#done;
#sed -i 's/<a href="http:\/\/hi.baidu.com\/%D6%D0%B9%FA%C4%D4%BD%EE/<a href="\.\./g' blog/index.html
#sed -i 's/<a href="\/%D6%D0%B9%FA%C4%D4%BD%EE/<a href="\.\./g' blog/index.html
#echo "handled blog/index.html"


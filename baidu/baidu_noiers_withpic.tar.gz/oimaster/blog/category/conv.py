import os
from urllib import unquote
files=os.listdir('.')
for file in files:
	nfile=unquote(file).decode('gbk').encode('utf-8')
	#os.rename(file,nfile)
	print 'mv %s to %s'%(file,nfile)

